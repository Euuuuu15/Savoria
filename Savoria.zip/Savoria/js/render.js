// render.js - small helpers that build pieces of the page.

// Create an element and set its text safely (textContent never runs typed HTML).
export function el(tag, text) {
  const node = document.createElement(tag);
  if (text) node.textContent = text;
  return node;
}
export const cap = text => text.charAt(0).toUpperCase() + text.slice(1);
export const cleanName = name => name.replace(/\s*\(.*?\)/g, "");   // "Rice (cooked)" -> "Rice"

// One result card. "item" is {recipe} or a scored {recipe, matched, total, missing}.
// "carry" is the current URL query, so the recipe page remembers your ingredients.
// A recipe photo. Only requested for recipes listed in data/photos.json, so a missing file never causes an error.
export function photo(recipe) {
  const img = el("img");
  img.src = "images/recipes/" + recipe.id + ".jpg";
  img.alt = recipe.imageAlt ?? "Photo of " + recipe.name;
  img.loading = "lazy";
  img.className = "recipe-photo";
  img.addEventListener("error", () => img.remove());
  return img;
}

export function recipeCard(item, carry, photos) {
  const r = item.recipe;
  const card = el("article");
  if (photos && photos.has(r.id)) card.append(photo(r));
  const link = el("a", r.name);
  link.href = "recipe.html?id=" + r.id + (carry ? "&" + carry : "");
  const title = el("h3");
  title.append(link);
  card.append(title);
  if (item.total !== undefined) {
    card.append(el("p", "Ingredients: " + item.matched + "/" + item.total + " matched"));
    const names = item.missing.map(name => cleanName(name).toLowerCase());
    card.append(el("p", "Missing: " + (names.length ? names.join(", ") : "nothing")));
  }
  card.append(el("p", (r.prepMinutes + r.cookMinutes) + " minutes · " + cap(r.difficulty) + " · Serves " + r.servings));
  return card;
}
