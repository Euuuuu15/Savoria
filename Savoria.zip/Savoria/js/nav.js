// nav.js - the mobile menu button.
const toggle = document.querySelector(".menu-toggle");
const nav = document.getElementById("main-nav");

// Tells the CSS that JavaScript is running, so the Menu button only appears when it can work.
document.documentElement.classList.add("has-js");

function setOpen(open) {
  nav.classList.toggle("open", open);
  toggle.setAttribute("aria-expanded", String(open));   // screen readers announce expanded or collapsed
}

if (toggle && nav) {
  toggle.addEventListener("click", () => setOpen(!nav.classList.contains("open")));
  document.addEventListener("keydown", event => {
    if (event.key === "Escape" && nav.classList.contains("open")) {
      setOpen(false);
      toggle.focus();
    }
  });
}
