// render.js - builds recipe cards and details (Phase 4)
