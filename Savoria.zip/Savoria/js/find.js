// find.js - the ingredient picker on the Find Recipes page.
import { loadJSON } from "./data.js";
import { findIngredient } from "./matcher.js";
import { readList, writeList, INGREDIENTS_KEY } from "./storage.js";

const form = document.querySelector("main form");
const groupsEl = document.getElementById("ingredient-groups");
const searchEl = document.getElementById("search");
const otherEl = document.getElementById("other");
const addButton = document.getElementById("add-other");
const selectedEl = document.getElementById("selected");
const statusEl = document.getElementById("status");

const GROUPS = [
  ["protein", "Protein"], ["grains", "Rice, noodles and grains"], ["vegetables", "Vegetables"],
  ["fruit", "Fruit"], ["aromatics", "Aromatics"], ["seasonings", "Sauces and seasonings"],
  ["dairy", "Dairy"], ["pantry", "Pantry"]
];

let ingredients = [];
let customGroup = null;   // the "Added by you" fieldset, created only when needed

// Small helper: create an element and set its text safely.
// textContent inserts plain text and never HTML, so typed tags cannot run as code.
function el(tag, text) {
  const node = document.createElement(tag);
  if (text) node.textContent = text;
  return node;
}

function makeItem(value, name, searchText) {
  const li = el("li");
  const label = el("label");
  const input = el("input");
  input.type = "checkbox";
  input.name = "ingredient";   // same name for all boxes: the URL becomes ?ingredient=rice&ingredient=eggs
  input.value = value;
  label.append(input, " " + name);
  label.dataset.name = name;
  label.dataset.search = searchText;
  li.append(label);
  return li;
}

function buildGroups() {
  groupsEl.replaceChildren();   // removes the short fallback list
  for (const [category, title] of GROUPS) {
    // Staples (salt, pepper, oil, water) are assumed, so they get no checkbox.
    const items = ingredients.filter(i => i.category === category && !i.staple);
    if (items.length === 0) continue;
    const fieldset = el("fieldset");
    const list = el("ul");
    fieldset.append(el("legend", title), list);
    for (const i of items) {
      list.append(makeItem(i.id, i.name, [i.name, ...i.aliases].join(" ").toLowerCase()));
    }
    groupsEl.append(fieldset);
  }
}

function labelName(label) {
  return label.dataset.name ?? label.textContent.trim();   // fallback list has no data attributes
}

function updateSelected() {
  const names = [...form.querySelectorAll('input[name="ingredient"]:checked')]
    .map(box => labelName(box.closest("label")));
  selectedEl.textContent = names.length
    ? names.length + " selected: " + names.join(", ")
    : "Nothing selected yet.";
}

function filterList() {
  const query = searchEl.value.trim().toLowerCase();
  let shown = 0;
  for (const li of groupsEl.querySelectorAll("li")) {
    const label = li.querySelector("label");
    const text = label.dataset.search ?? label.textContent.toLowerCase();
    li.hidden = !text.includes(query);
    if (!li.hidden) shown++;
  }
  for (const fieldset of groupsEl.querySelectorAll("fieldset")) {
    fieldset.hidden = !fieldset.querySelector("li:not([hidden])");   // hide empty groups
  }
  statusEl.textContent = shown === 0 ? "No ingredients match your search. Try adding it below." : "";
}

function addOther() {
  const text = otherEl.value.trim();
  if (!text) { statusEl.textContent = "Type an ingredient first."; return; }

  const found = findIngredient(text, ingredients);
  if (found && found.staple) {
    statusEl.textContent = found.name + " is assumed, so you don’t need to add it.";
  } else if (found) {
    const box = groupsEl.querySelector('input[value="' + found.id + '"]');
    box.checked = true;
    box.closest("li").hidden = false;
    box.closest("fieldset").hidden = false;
    statusEl.textContent = "Selected " + found.name + ".";
  } else {
    // Not in our list: add it as its own checkbox so it is still sent to the results page.
    if (!customGroup) {
      customGroup = el("fieldset");
      customGroup.append(el("legend", "Added by you"), el("ul"));
      groupsEl.append(customGroup);
    }
    const value = text.toLowerCase();
    const existing = customGroup.querySelector("input")
      && [...customGroup.querySelectorAll("input")].find(box => box.value === value);
    if (existing) {
      statusEl.textContent = text + " is already added.";
    } else {
      const item = makeItem(value, text, value);
      item.querySelector("input").checked = true;
      customGroup.querySelector("ul").append(item);
      statusEl.textContent = "Added " + text + ". Savoria may not have recipes that use it.";
    }
  }
  otherEl.value = "";
  updateSelected();
  persist();
}

function persist() {
  writeList(INGREDIENTS_KEY, [...form.querySelectorAll('input[name="ingredient"]:checked')].map(box => box.value));
}

function restore() {
  const saved = readList(INGREDIENTS_KEY);
  if (saved.length === 0) return;
  const boxes = [...form.querySelectorAll('input[name="ingredient"]')];
  for (const value of saved) {
    const box = boxes.find(b => b.value === value);
    if (box) box.checked = true;
    else { otherEl.value = value; addOther(); }       // an ingredient the user typed last time
  }
  statusEl.textContent = "Restored your ingredients from last time.";
}

// ---- events ----
form.addEventListener("change", () => { updateSelected(); persist(); });          // one listener covers every checkbox
searchEl.addEventListener("input", filterList);
addButton.addEventListener("click", addOther);

// Pressing Enter in these two boxes should search or add, not submit the whole form.
for (const box of [searchEl, otherEl]) {
  box.addEventListener("keydown", event => {
    if (event.key !== "Enter") return;
    event.preventDefault();
    if (box === otherEl) addOther();
  });
}

form.addEventListener("reset", () => {
  setTimeout(() => { filterList(); updateSelected(); statusEl.textContent = ""; persist(); }, 0);   // wait for the browser to finish resetting
});

// ---- start ----
try {
  ingredients = (await loadJSON("data/ingredients.json")).ingredients;
  buildGroups();
} catch (error) {
  statusEl.textContent = "Could not load the full list, so a short list is shown. Run the site with Live Server.";
}
restore();
updateSelected();
