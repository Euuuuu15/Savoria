// recipe.js - one page template that shows any recipe, chosen by ?id= in the URL.
import { loadJSON } from "./data.js";
import { findIngredient } from "./matcher.js";
import { readList, writeList, FAVORITES_KEY } from "./storage.js";
import { el, cap, cleanName } from "./render.js";

// Defined first: code at the top of a module runs in order, so this must exist before show() is called.
const SINGULAR = { potatoes: "potato", carrots: "carrot", tomatoes: "tomato", eggs: "egg", hotdogs: "hotdog", bananas: "banana" };

const params = new URLSearchParams(location.search);
const setText = (id, text) => { document.getElementById(id).textContent = text; };

try {
  const [{ recipes }, { ingredients }, { categories }, { photos }] = await Promise.all([
    loadJSON("data/recipes.json"), loadJSON("data/ingredients.json"), loadJSON("data/categories.json"), loadJSON("data/photos.json")
  ]);
  const recipe = recipes.find(r => r.id === params.get("id"));
  if (recipe) show(recipe, ingredients, categories, new Set(photos)); else notFound("Recipe not found", "That recipe doesn’t exist. Try the categories page or search by ingredient.");
} catch (error) {
  notFound("Could not load the recipe", "Run the site with Live Server and try again.");
}

function notFound(title, text) {
  setText("recipe-name", title);
  setText("recipe-desc", text);
  document.title = title + " - Savoria";
  for (const section of document.querySelectorAll("main section")) section.hidden = true;
  document.getElementById("save-button").hidden = true;
}

function lineText(line, byId) {
  const name = cleanName(byId[line.ingredientId].name);
  let label = name.toLowerCase();
  const amount = line.amount ?? "";
  if (/^1( (small|medium|large))?$/.test(amount)) label = SINGULAR[label] ?? label;   // "1 medium potatoes" -> "1 medium potato"
  if (/\bcan\b/.test(amount)) label = label.replace(/^canned /, "");                   // "1 can canned sardines" -> "1 can sardines"
  if (line.role === "serving") return name + ", for serving";
  let text = line.amount ? line.amount + " " + label : name;
  if (line.note) text += ", " + line.note;
  return text;
}

function suffix(line, have) {
  if (line.role === "staple") return " (assumed pantry item)";
  if (line.role === "optional") return " (optional)";
  if (have.size && have.has(line.ingredientId)) return " (you have this)";
  if (line.group) return " (either one works)";
  return have.size && line.role === "required" ? " (you need this)" : "";
}

function show(recipe, ingredients, categories, photos) {
  const byId = Object.fromEntries(ingredients.map(i => [i.id, i]));
  const have = new Set();
  for (const raw of params.getAll("ingredient")) {
    const found = findIngredient(raw, ingredients);
    if (found) have.add(found.id);
  }

  document.title = recipe.name + " - Savoria";
  setText("recipe-name", recipe.name);
  setText("crumb-name", recipe.name);
  setText("recipe-desc", recipe.description);

  if (photos.has(recipe.id)) {                        // only recipes listed in data/photos.json get a picture
    const img = document.getElementById("recipe-photo");
    img.alt = recipe.imageAlt ?? "Photo of " + recipe.name;
    img.addEventListener("load", () => { img.hidden = false; });
    img.addEventListener("error", () => img.remove());
    img.src = "images/recipes/" + recipe.id + ".jpg";
  }

  const saveButton = document.getElementById("save-button");   // aria-pressed tells screen readers if it is on
  const refresh = () => saveButton.setAttribute("aria-pressed", String(readList(FAVORITES_KEY).includes(recipe.id)));
  saveButton.addEventListener("click", () => {
    const list = readList(FAVORITES_KEY);
    writeList(FAVORITES_KEY, list.includes(recipe.id) ? list.filter(id => id !== recipe.id) : [...list, recipe.id]);
    refresh();
  });
  refresh();

  const back = new URLSearchParams(params);    // everything except the recipe id goes back to the results page
  back.delete("id");
  const href = "results.html" + (back.size ? "?" + back : "");
  document.getElementById("crumb-results").href = href;
  document.getElementById("back-link").href = href;

  const facts = document.getElementById("recipe-facts");
  for (const text of ["Prep: " + recipe.prepMinutes + " minutes", "Cook: " + recipe.cookMinutes + " minutes",
                      "Serves: " + recipe.servings, "Difficulty: " + cap(recipe.difficulty)]) facts.append(el("li", text));

  const cats = document.getElementById("recipe-cats");
  cats.append("Categories: ");
  recipe.categories.forEach((id, index) => {
    const category = categories.find(c => c.id === id);
    if (!category) return;
    if (index) cats.append(", ");
    const link = el("a", category.name);
    link.href = "results.html?category=" + id;
    cats.append(link);
  });

  if (have.size) setText("ing-note", "Based on the ingredients you selected.");
  const list = document.getElementById("ing-list");
  for (const line of recipe.ingredients) list.append(el("li", lineText(line, byId) + suffix(line, have)));

  const steps = document.getElementById("steps-list");
  for (const step of recipe.steps) steps.append(el("li", step));

  if (recipe.substitutions.length) {
    const subs = document.getElementById("sub-list");
    for (const sub of recipe.substitutions) subs.append(el("li", cleanName(byId[sub.ingredientId].name) + ": use " + sub.use + ". " + sub.note));
    document.getElementById("sub-section").hidden = false;
  }

  const body = document.getElementById("nut-body");
  if (recipe.nutrition) {
    const table = el("table");
    table.append(el("caption", "Estimated nutrition per serving"));
    for (const [name, value] of Object.entries(recipe.nutrition).filter(([name]) => name !== "source")) {
      const row = el("tr");
      const head = el("th", cap(name)); head.scope = "row";
      row.append(head, el("td", String(value)));
      table.append(row);
    }
    body.append(table);
    if (recipe.nutrition.source) body.append(el("p", "Source: " + recipe.nutrition.source));
  } else {
    body.append(el("p", "Nutrition information is not available for this recipe yet."));
  }
}
