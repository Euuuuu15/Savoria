// home.js - fills the live numbers and Today's Picks on the Home page.
import { loadJSON } from "./data.js";
import { el } from "./render.js";

try {
  const [{ recipes }, { ingredients }, { categories }] = await Promise.all([
    loadJSON("data/recipes.json"), loadJSON("data/ingredients.json"), loadJSON("data/categories.json")
  ]);
  document.getElementById("stat-recipes").textContent = recipes.length;
  document.getElementById("stat-ingredients").textContent = ingredients.length;
  document.getElementById("stat-categories").textContent = categories.length;

  // A number that changes once per calendar day, so each day shows different picks.
  const now = new Date();
  const day = Math.floor(Date.UTC(now.getFullYear(), now.getMonth(), now.getDate()) / 86400000);

  for (const meal of ["breakfast", "lunch", "dinner"]) {
    const pool = recipes.filter(r => r.categories.includes(meal));
    if (pool.length === 0) continue;
    const pick = pool[day % pool.length];                 // % wraps around the list
    const link = el("a", pick.name);
    link.href = "recipe.html?id=" + pick.id;
    const slot = document.getElementById("pick-" + meal);
    slot.textContent = "";
    slot.append(link);
    document.getElementById("pick-" + meal + "-time").textContent = (pick.prepMinutes + pick.cookMinutes) + " minutes";
  }
} catch (error) {
  // If loading fails, the hand-written content already in the page stays as a fallback.
}
