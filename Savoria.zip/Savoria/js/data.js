// data.js - loads our JSON data files.
// "export" lets other files import this function.
export async function loadJSON(path) {
  // fetch() asks the server for a file and returns a Promise (a "promise of a result later").
  const response = await fetch(path);
  if (!response.ok) {
    throw new Error("Could not load " + path + " (status " + response.status + ")");
  }
  // .json() turns the file's text into real JavaScript objects and arrays.
  return response.json();
}
