Put one photo per recipe here, named <recipe id>.jpg (about 4:3 shape, under 200 KB).
Then add the recipe id to the list in data/photos.json, for example:  {"photos": ["chicken-curry"]}
Use only photos you took or have permission to use.

Recipe ids:
garlic-fried-rice-with-egg
ginisang-sardinas
egg-and-tomato-stir-fry
pancit-canton-with-vegetables
chicken-tinola
tortang-talong
ginisang-repolyo-with-egg
hotdog-with-egg
ginisang-sayote
tuna-omelette
soy-sauce-chicken
ginisang-pechay
sardines-with-misua
tokwa-with-soy-sauce
corned-beef-with-potato
egg-drop-soup
banana-pancakes
ginisang-togue
chicken-adobo-flakes
ginataang-kalabasa-at-sitaw
pork-giniling-with-potatoes
fried-rice-with-hotdog
ginisang-kalabasa
chicken-curry
sopas
tofu-and-vegetable-stir-fry
paksiw-na-isda
filipino-style-cheese-omelette
monggo-with-malunggay
banana-and-oatmeal-pancakes
