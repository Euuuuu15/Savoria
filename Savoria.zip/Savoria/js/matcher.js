// matcher.js - understands what people type. (Recipe scoring is added here in Phase 4.)

// Cleans text so "Tomatoes ", "tomato" and "Rice (cooked)" can be compared fairly.
// Both sides are cleaned the same way, so they still match each other.
export function normalize(text) {
  return text.toLowerCase().replace(/\s*\(.*?\)/g, "").trim().replace(/s$/, "");
}

// Looks for an ingredient whose id, name or any alias matches the typed text.
// Returns the ingredient object, or null if nothing matches.
export function findIngredient(text, ingredients) {
  const wanted = normalize(text);
  if (!wanted) return null;
  return ingredients.find(item =>
    [item.id, item.name, ...item.aliases].some(name => normalize(name) === wanted)
  ) ?? null;
}
