// results.js - reads the URL, filters and ranks recipes, and builds the cards.
import { loadJSON } from "./data.js";
import { findIngredient, rankRecipes } from "./matcher.js";
import { el, recipeCard, cleanName } from "./render.js";
import { readList, FAVORITES_KEY } from "./storage.js";

const params = new URLSearchParams(location.search);   // ?ingredient=rice&ingredient=eggs becomes a lookup object
const summaryEl = document.getElementById("results-summary");

try {
  const [{ recipes }, { ingredients }, { categories }, { photos }] = await Promise.all([
    loadJSON("data/recipes.json"), loadJSON("data/ingredients.json"), loadJSON("data/categories.json"), loadJSON("data/photos.json")
  ]);
  show(recipes, ingredients, categories, new Set(photos));
} catch (error) {
  summaryEl.textContent = "Could not load recipes. Run the site with Live Server.";
}

function show(recipes, ingredients, categories, photos) {
  const byId = Object.fromEntries(ingredients.map(i => [i.id, i]));

  // 1. What the user chose. Typed names are turned into ids; unknown ones are remembered.
  const have = new Set();
  const unknown = [];
  for (const raw of params.getAll("ingredient")) {
    const found = findIngredient(raw, ingredients);
    if (found) have.add(found.id); else unknown.push(raw);
  }
  const category = categories.find(c => c.id === params.get("category"));
  const savedMode = params.get("saved") === "1";
  const saved = new Set(readList(FAVORITES_KEY));
  const maxTime = Number(params.get("time")) || 0;
  const difficulty = params.get("difficulty") || "";

  // 2. Filter, then 3. rank (or just sort by name when no ingredients were chosen).
  const pool = recipes.filter(r =>
    (!savedMode || saved.has(r.id)) &&
    (!category || r.categories.includes(category.id)) &&
    (!maxTime || r.cookMinutes <= maxTime) &&
    (!difficulty || r.difficulty === difficulty));
  const searching = have.size > 0 || unknown.length > 0;
  const ranked = searching ? rankRecipes(pool, have, byId).filter(item => item.matched > 0) : [];
  const strong = ranked.filter(item => item.score >= 0.5);       // at least half of the recipe's ingredients
  const results = searching
    ? (strong.length ? strong : ranked.slice(0, 5))              // nothing strong? show the 5 closest instead
    : pool.map(recipe => ({ recipe })).sort((a, b) => a.recipe.name.localeCompare(b.recipe.name));

  // 4. Fill in the page.
  document.getElementById("results-title").textContent = savedMode ? "Saved recipes" : category ? category.name + " recipes" : "Recipe results";
  if (category || savedMode) document.title = (savedMode ? "Saved recipes" : category.name + " recipes") + " - Savoria";

  if (have.size || unknown.length) {
    const list = document.getElementById("yours-list");
    for (const id of have) list.append(el("li", cleanName(byId[id].name)));
    for (const name of unknown) list.append(el("li", name));
    document.getElementById("yours").hidden = false;
  }

  const form = document.getElementById("filters");
  document.getElementById("time").value = params.get("time") ?? "";
  document.getElementById("difficulty").value = difficulty;
  for (const [key, value] of params) {           // keep the chosen ingredients and category when filters are applied
    if (key !== "ingredient" && key !== "category" && key !== "saved") continue;
    const hidden = el("input");
    hidden.type = "hidden"; hidden.name = key; hidden.value = value;
    form.append(hidden);
  }

  let message;
  if (results.length === 0) message = savedMode && !searching && !maxTime && !difficulty ? "You haven’t saved any recipes yet. Open a recipe and press Save recipe." : searching ? "No recipes use those ingredients with the current filters." : "No recipes match the current filters.";
  else if (searching && results[0].score < 1) message = "No recipe matches completely. Here are the closest matches (" + results.length + ").";
  else message = results.length + (results.length === 1 ? " recipe found." : " recipes found.");
  if (unknown.length) message += " Savoria has no recipes that use: " + unknown.join(", ") + ".";
  const hiddenCount = ranked.length - results.length;
  if (hiddenCount > 0) message += " " + hiddenCount + " weaker " + (hiddenCount === 1 ? "match is" : "matches are") + " hidden.";
  summaryEl.textContent = message;

  const matches = document.getElementById("matches");
  for (const item of results) matches.append(recipeCard(item, params.toString(), photos));
}
