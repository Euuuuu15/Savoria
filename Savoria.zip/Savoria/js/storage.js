// storage.js - remembers things in the browser (localStorage). Every call is wrapped in try/catch
// because storage can be blocked (private mode) or full, and the site must still work then.
export const INGREDIENTS_KEY = "savoria.ingredients";
export const FAVORITES_KEY = "savoria.favorites";

export function readList(key) {
  try {
    const value = JSON.parse(localStorage.getItem(key));
    return Array.isArray(value) ? value.map(String) : [];
  } catch (error) { return []; }
}
export function writeList(key, list) {
  try { localStorage.setItem(key, JSON.stringify(list)); } catch (error) { /* ignore */ }
}
