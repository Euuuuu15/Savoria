// matcher.js - understands what people type. (Recipe scoring is added here in Phase 4.)

// Cleans text so "Tomatoes ", "tomato" and "Rice (cooked)" can be compared fairly.
// Both sides are cleaned the same way, so they still match each other.
export function normalize(text) {
  return text.toLowerCase().replace(/\s*\(.*?\)/g, "").trim().replace(/s$/, "");
}

// Looks for an ingredient whose id, name or any alias matches the typed text.
// Returns the ingredient object, or null if nothing matches.
export function findIngredient(text, ingredients) {
  const wanted = normalize(text);
  if (!wanted) return null;
  return ingredients.find(item =>
    [item.id, item.name, ...item.aliases].some(name => normalize(name) === wanted)
  ) ?? null;
}

// ---------- Phase 4: scoring ----------
// A "need" is one thing the recipe requires. It is a list of ingredient ids, and having ANY one of them satisfies it.
// Plain required ingredient -> a need with one id. Either/or group (calamansi or vinegar) -> a need with two ids.
// Staples, optional and "for serving" items are never needs. A group that includes a staple (salt or fish sauce) is
// already satisfied, so it is skipped.
export function scoreRecipe(recipe, have, byId) {
  const needs = [];
  const groups = new Map();
  for (const line of recipe.ingredients) {
    if (line.group) {
      if (!groups.has(line.group)) groups.set(line.group, []);
      groups.get(line.group).push(line);
    } else if (line.role === "required") {
      needs.push([line.ingredientId]);
    }
  }
  for (const lines of groups.values()) {
    if (!lines.some(line => line.role === "staple")) needs.push(lines.map(line => line.ingredientId));
  }
  const missing = needs.filter(ids => !ids.some(id => have.has(id)));
  const matched = needs.length - missing.length;
  return {
    recipe, matched, total: needs.length,
    score: needs.length ? matched / needs.length : 1,
    missing: missing.map(ids => ids.map(id => byId[id].name).join(" or "))
  };
}

// Best match first. Ties: more matched ingredients, then fewer missing items, then shorter total time, then name.
export function rankRecipes(recipes, have, byId) {
  const time = r => r.prepMinutes + r.cookMinutes;
  return recipes.map(recipe => scoreRecipe(recipe, have, byId)).sort((a, b) =>
    b.score - a.score ||
    b.matched - a.matched ||
    a.missing.length - b.missing.length ||
    time(a.recipe) - time(b.recipe) ||
    a.recipe.name.localeCompare(b.recipe.name));
}
